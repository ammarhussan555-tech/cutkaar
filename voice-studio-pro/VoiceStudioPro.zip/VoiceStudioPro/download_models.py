"""Downloads all AI models once, during install, so the app starts ready."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("HF_HOME", str(ROOT / "models"))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")

from huggingface_hub import hf_hub_download, snapshot_download

import sys
sys.path.insert(0, str(ROOT))
from app import KOKORO  # noqa: E402  (same voice list as the app)


def step(msg):
    print(f"\n==> {msg}", flush=True)


step("Kokoro premium voices (~350 MB)")
hf_hub_download("hexgrad/Kokoro-82M", "config.json")
hf_hub_download("hexgrad/Kokoro-82M", "kokoro-v1_0.pth")
for vid in KOKORO.values():
    hf_hub_download("hexgrad/Kokoro-82M", f"voices/{vid}.pt")

if "--lite" in sys.argv:
    print("\nKokoro voices download ho gayin!", flush=True)
    sys.exit(0)

step("Chatterbox Turbo - voice cloning (~1.5 GB)")
snapshot_download("ResembleAI/chatterbox-turbo",
                  allow_patterns=["*.safetensors", "*.json", "*.txt", "*.pt", "*.model"])

step("Chatterbox Expressive - emotion control (~3 GB)")
for f in ["ve.safetensors", "t3_cfg.safetensors", "s3gen.safetensors", "tokenizer.json", "conds.pt"]:
    hf_hub_download("ResembleAI/chatterbox", f)

print("\nSab models download ho gaye!", flush=True)
