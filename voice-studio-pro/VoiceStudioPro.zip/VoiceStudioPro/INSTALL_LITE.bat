@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Voice Studio Pro LITE - Install

echo.
echo  ==========================================================
echo    Voice Studio Pro LITE - kam RAM wale PC ke liye
echo    28 premium voices, tez, offline.  (~1.5 GB download)
echo  ==========================================================
echo.

set "UV_PYTHON_INSTALL_DIR=%~dp0tools\python"
set "UV_CACHE_DIR=%~dp0tools\cache"
set "UV_LINK_MODE=copy"
set "HF_HOME=%~dp0models"

if not exist "tools\uv.exe" (
  echo [1/4] Installer tools download ho rahe hain...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:UV_UNMANAGED_INSTALL='%~dp0tools'; irm https://astral.sh/uv/install.ps1 | iex"
)
if not exist "tools\uv.exe" (
  echo  [X] uv download nahi hua. Internet check karein aur dobara chalayein.
  pause & exit /b 1
)

echo [2/4] Python 3.11 tayyar ho raha hai...
if not exist ".venv\Scripts\python.exe" (
  tools\uv.exe venv --python 3.11 .venv
  if errorlevel 1 ( echo  [X] Python install nahi hua. & pause & exit /b 1 )
)

echo [3/4] Voice engine install ho raha hai...
tools\uv.exe pip install --python .venv\Scripts\python.exe torch==2.6.0 --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 ( echo  [X] PyTorch install nahi hua. Dobara chalayein. & pause & exit /b 1 )
tools\uv.exe pip install --python .venv\Scripts\python.exe kokoro==0.9.4 gradio==6.8.0 lameenc soundfile librosa "numpy<2" "https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl"
if errorlevel 1 ( echo  [X] Engine install nahi hua. Dobara chalayein. & pause & exit /b 1 )

echo [4/4] Voices download ho rahi hain ^(~350 MB^)...
.venv\Scripts\python.exe download_models.py --lite

echo.
echo  ==========================================================
echo    Install mukammal!  Ab START.bat par double-click karein.
echo  ==========================================================
echo.
pause
