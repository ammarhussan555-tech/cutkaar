@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Voice Studio Pro
set "HF_HOME=%~dp0models"
set "PYTHONIOENCODING=utf-8"

if not exist ".venv\Scripts\python.exe" (
  echo  Pehle INSTALL.bat chalayein.
  pause & exit /b 1
)

echo.
echo  Voice Studio Pro shuru ho raha hai... browser khud khul jayega.
echo  Agar na khule to browser mein ye kholein:  http://127.0.0.1:7860
echo  Band karne ke liye ye kala window close kar dein.
echo.
.venv\Scripts\python.exe app.py
pause
