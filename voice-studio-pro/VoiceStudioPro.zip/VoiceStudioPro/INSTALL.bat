@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Voice Studio Pro - Install

echo.
echo  ==========================================================
echo    Voice Studio Pro - Install  (sirf aik dafa)
echo    Internet chahiye. 10-30 minute lag sakte hain.
echo  ==========================================================
echo.

set "UV_PYTHON_INSTALL_DIR=%~dp0tools\python"
set "UV_CACHE_DIR=%~dp0tools\cache"
set "UV_LINK_MODE=copy"
set "HF_HOME=%~dp0models"

rem ---------- 1. uv (package manager, downloads Python too) ----------
if not exist "tools\uv.exe" (
  echo [1/5] Installer tools download ho rahe hain...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$env:UV_UNMANAGED_INSTALL='%~dp0tools'; irm https://astral.sh/uv/install.ps1 | iex"
)
if not exist "tools\uv.exe" (
  echo.
  echo  [X] uv download nahi hua. Internet check karein aur INSTALL.bat dobara chalayein.
  pause & exit /b 1
)

rem ---------- 2. Python 3.11 + virtual env ----------
echo [2/5] Python 3.11 tayyar ho raha hai...
if not exist ".venv\Scripts\python.exe" (
  tools\uv.exe venv --python 3.11 .venv
  if errorlevel 1 ( echo  [X] Python install nahi hua. & pause & exit /b 1 )
)

rem ---------- 3. PyTorch (GPU if NVIDIA card is present) ----------
where nvidia-smi >nul 2>nul
if %errorlevel%==0 (
  echo [3/5] NVIDIA graphics card mila - GPU version install ho raha hai ^(~2.5 GB^)...
  tools\uv.exe pip install --python .venv\Scripts\python.exe torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124
) else (
  echo [3/5] NVIDIA card nahi mila - CPU version install ho raha hai...
  tools\uv.exe pip install --python .venv\Scripts\python.exe torch==2.6.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cpu
)
if errorlevel 1 ( echo  [X] PyTorch install nahi hua. Internet check karke dobara chalayein. & pause & exit /b 1 )

rem ---------- 4. AI engines ----------
echo [4/5] AI voice engines install ho rahe hain...
tools\uv.exe pip install --python .venv\Scripts\python.exe chatterbox-tts==0.1.7 kokoro==0.9.4 lameenc soundfile "setuptools<81" "https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl"
if errorlevel 1 ( echo  [X] Engines install nahi hue. Dobara chalayein. & pause & exit /b 1 )

rem ---------- 5. Models ----------
echo [5/5] AI models download ho rahe hain ^(~5 GB, sirf pehli dafa^)...
.venv\Scripts\python.exe download_models.py
if errorlevel 1 (
  echo.
  echo  [!] Kuch models download nahi hue. Koi baat nahi - app pehli dafa chalne par khud download kar lega.
)

echo.
echo  ==========================================================
echo    Install mukammal!  Ab START.bat par double-click karein.
echo  ==========================================================
echo.
pause
